from app import app
from flask import flash, request, redirect, render_template, session, abort, make_response, url_for
from werkzeug.security import generate_password_hash,check_password_hash
from lms.app.db import mysql
from lms.app import app, COOKIE_TIME_OUT

import pymysql
db_name = "library"
table = "admin_reg"
table2 = "student_reg"
table3 ="books"
table4= "assignments"
table5 ="student_books"
table6 = "student_assign"
table7 = "student_complaints"

@app.route('/')
def Home():
    return render_template('index.html')

@app.route('/admin_login')
def admin_login():
    return render_template('adm_login.html')

@app.route('/admin_reg')
def admin_reg():
    return render_template('admin_reg.html')

@app.route("/admin_reg1",methods=['POST'])
def admin_reg1():
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    First_name = request.form.get("firstname")
    last_name = request.form.get("lastname")

    Email = request.form.get("email")
    Password = request.form.get("password")
    cursor = db.cursor()
    cursor.execute('SELECT * FROM ' + table + ' WHERE EMail=%s', (Email))
    row = cursor.fetchone()
    if row:
        flash('Email already Exists')
        return redirect('/admin_reg')

    else:
        New_password = generate_password_hash(password=Password)
        cursor = db.cursor()
        cursor.execute('INSERT INTO ' + table + ' VALUES (%s,%s, %s, %s, %s)',
                       (" ",First_name, last_name,
                        Email, New_password))
        db.commit()
        return render_template('adm_login.html')

@app.route('/admin_login1',methods=['POST',"GET"])
def admin_login1():
    conn = None
    cursor = None

    _email = request.form['inputEmail']
    _password = request.form['inputPassword']
    if request.method == 'POST':
        if _email and _password:
            # check user exists
            conn = mysql.connect()
            cursor = conn.cursor()
            sql = "SELECT * FROM admin_reg WHERE Email=%s"
            sql_where = (_email,)
            cursor.execute(sql, sql_where)
            row = cursor.fetchone()
            if row:
                if check_password_hash(row[4], _password):
                    session['email'] = row[3]
                    session["name"]=str(row[1]+" "+row[2])
                    cursor.close()
                    conn.close()
                    return render_template('admin_profile.html', name=str(row[1]+" "+row[2]), email=str(_email))
                else:
                    flash('Enter valid credentials')
                    return redirect('/admin_login')
            else:
                flash('Enter valid credentials')
                return redirect('/admin_login')
        else:
            flash('Enter valid credentials')
            return redirect('/admin_login')
    elif 'email' in session:
        conn = mysql.connect()
        cursor = conn.cursor()
        sql = "SELECT * FROM admin_reg WHERE Email=%s"
        _email = session['email']
        sql_where = (_email,)
        cursor.execute(sql, sql_where)
        row = cursor.fetchone()
        if row:
            if check_password_hash(row[4], _password):
                session['email'] = row[3]
                session["name"] = str(row[1] + " " + row[2])
                cursor.close()
                conn.close()
                return render_template('admin_profile.html', name=str(row[1] + " " + row[2]), email=str(_email))
        else:
            flash('Enter valid credentials')
            return redirect('/admin_login')

@app.route('/adminhome',methods=['POST',"GET"])
def adminhome():
    if 'email' in session:
        conn = mysql.connect()
        cursor = conn.cursor()
        sql = "SELECT * FROM admin_reg WHERE Email=%s"
        _email = session['email']
        sql_where = (_email,)
        cursor.execute(sql, sql_where)
        row = cursor.fetchone()
        if row:
            return render_template('admin_profile.html', name=str(row[1] + " " + row[2]), email=str(_email))
        else:
            flash('Enter valid credentials')
            return redirect('/admin_login')

@app.route('/booksList')
def booksList():
    conn = mysql.connect()
    cursor = conn.cursor()
    std_c_name = "SELECT * FROM books"
    cursor.execute(std_c_name)
    bk = cursor.fetchall()
    cursor.close()
    conn.close()

    conn = mysql.connect()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(book_id) as Books_count from books")
    Total = cursor.fetchone()

    cursor.close()
    conn.close()

    conn = mysql.connect()
    cursor = conn.cursor()
    cursor.execute("SELECT author,COUNT(unique_id) as Books_count from books GROUP BY author")
    numbers = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('books_list.html', books = bk, name= session["name"],numbers=numbers, total = Total)

@app.route('/books')
def books():
    return render_template('books.html')

@app.route('/createbook',methods=['POST'])
def createbook():
    db = mysql.connect()
    book_id = request.form.get("book_id")
    book_name = request.form.get("book_name")
    Description = request.form.get("Description")
    Author = request.form.get("Author")
    cursor = db.cursor()
    cursor.execute('INSERT INTO ' + table3 + ' (book_id, name, Description,author,Status) VALUES (%s, %s, %s,%s,%s)', (book_id, book_name, Description,Author,"Available"))
    db.commit()
    return redirect('/booksList')

@app.route('/books_add',methods=['POST'])
def books_add():
    global details, form, Name, c_name, email
    #db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    if request.method == 'POST':

        course_id_new = request.form.to_dict()

        for i in course_id_new:
            details = str(i)
            if(course_id_new.get(details) == 'Edit'):
                bookID = ''
                Name=''
                Description=''
                Author=''
                conn = mysql.connect()
                cursor = conn.cursor()
                std_c_name = "SELECT * FROM books WHERE book_id = %s"
                sql_where = (details)
                cursor.execute(std_c_name, sql_where)
                assn = cursor.fetchall()
                x = cursor.rowcount
                if x == 1:
                    for row in assn:
                        bookID = str(row[1])
                        Name = str(row[2])
                        Description = str(row[3])
                        Author = str(row[4])

                return render_template('books_edit.html', book_id=bookID, book_name=Name, Description=Description,Author=Author)
            elif(course_id_new.get(details) =='Delete'):
                conn = mysql.connect()
                cursor = conn.cursor()
                std_c_name = "DELETE FROM books WHERE book_id = %s"
                sql_where = (details)
                cursor.execute(std_c_name, sql_where)
                conn.commit()
                return redirect('/booksList')


    return redirect('/booksList')

@app.route('/booksedit',methods=['POST'])
def booksEdit():
    db = mysql.connect()
    book_id = request.form.get("book_id")
    book_name = request.form.get("book_name")
    Description = request.form.get("Description")
    Author = request.form.get("Author")

    cursor = db.cursor()
    cursor.execute('UPDATE books set name=%s,Description=%s,Author=%s where book_id= %s',
                   (book_name, Description,Author, book_id))
    db.commit()
    return redirect('/booksList')


@app.route('/stu_reg')
def stu_reg():

    return render_template('stu_reg.html')

@app.route("/stu_reg1",methods=['POST'])
def stu_reg1():
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    name = request.form.get("username")
    course = request.form.get("course")
    semester = request.form.get("semester")
    Form_no = request.form.get("Form_no")
    Contact = request.form.get("Contact")
    Email = request.form.get("email")
    Password = request.form.get("password")
    Address = request.form.get("Address")
    new_password = generate_password_hash(password=Password)
    cursor = db.cursor()

    cursor.execute('SELECT * FROM ' + table2 + ' WHERE EMail_address=%s', (Email))
    row = cursor.fetchone()
    if row:
        flash('Email already Exists')
        return redirect('/stu_reg')

    else:
        cursor.execute('INSERT INTO ' + table2 + ' VALUES (%s,%s, %s, %s, %s,%s, %s, %s, %s)', (" ",name,course,semester,str(Form_no),str(Contact),
                                                                                             Email,new_password,Address))
        db.commit()
        return render_template('login.html')

@app.route('/stu_login')
def stu_login():
    return render_template('login.html')

@app.route('/stu_login1', methods=['POST'])
def stu_login1():
    conn = None
    cursor = None

    _email = request.form['inputEmail']
    _password = request.form['inputPassword']
    global username
    username = _email
    if _email and _password:
            # check user exists
            conn = mysql.connect()
            cursor = conn.cursor()
            sql = "SELECT * FROM student_reg WHERE Email_address=%s"
            sql_where = (_email,)
            cursor.execute(sql, sql_where)
            row = cursor.fetchone()
            if row:
                    if check_password_hash(row[7], _password):
                        session['email'] = row[6]
                        cursor.close()
                        conn.close()

                        return render_template('profile.html', name=str(row[1]),  number=row[4],
                                               email=row[5], formno=row[2], )
                    else:
                        flash('Enter valid credentials')
                        return redirect('/stu_login')


            else:
                flash('Invalid email/password!')
                return redirect('/stu_login')
    else:
        flash('Invalid email/password!')
        return redirect('/stu_login')

@app.route('/profiles')
def profiles():
    conn = None
    cursor = None

    _email = session['email']
    global username
    username = _email

    if _email:
            # check user exists
            conn = mysql.connect()
            cursor = conn.cursor()
            sql = "SELECT * FROM student_reg WHERE Email_address=%s"
            sql_where = (_email,)
            cursor.execute(sql, sql_where)
            row = cursor.fetchone()
            if row:
                    session['email'] = row[6]
                    cursor.close()
                    conn.close()

                    return render_template('profile.html', name=str(row[1]), number=row[4],
                                           email=row[5], formno=row[2])

            else:
                flash('Invalid email/password!')
                return redirect('/stu_login')
    else:
        flash('Invalid email/password!')
        return redirect('/stu_login')

@app.route('/studentbooks')
def studentbooks():
    conn = None
    cursor = None

    _email = session['email']
    global username
    username = _email

    if _email:
            # check user exists
            conn = mysql.connect()
            cursor = conn.cursor()
            sql = "SELECT * FROM student_reg WHERE Email_address=%s"
            sql_where = (_email,)
            cursor.execute(sql, sql_where)
            row = cursor.fetchone()
            if row:
                    session['email'] = row[6]
                    cursor.close()
                    conn.close()
                    conn = mysql.connect()  # intial connection

                    cursor = conn.cursor()
                    sql_course = "SELECT * FROM books;"
                    cursor.execute(sql_course)
                    stu_books = cursor.fetchall()

                    cursor.close()
                    conn.close()


                    conn = mysql.connect()  # intial connection
                    cursor = conn.cursor()
                    sql_comp_course = "SELECT * FROM student_books WHERE email=%s"
                    sql_where = (username)
                    cursor.execute(sql_comp_course, sql_where)
                    sel_books = cursor.fetchall()

                    cursor.close()
                    conn.close()

                    conn = mysql.connect()  # intial connection
                    cursor = conn.cursor()
                    cursor.execute("SELECT COUNT(email) as total from student_books where email =%s",(_email))
                    Total=cursor.fetchone()
                    print(Total)

                    return render_template('student_books.html', name=str(row[1]), books=stu_books, number=row[4],
                                           email=row[5], formno=row[2],
                                           sel_books=sel_books,total=Total)


            else:
                flash('Invalid email/password!')
                return redirect('/stu_login')
    else:
        flash('Invalid email/password!')
        return redirect('/stu_login')

@app.route('/books_save',methods=['POST'])
def books_save():
    global details, form, Name, c_name, email, b_name, author, unique_id
    #db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    if request.method == 'POST':

        book_id_new = request.form.to_dict()


        for i in book_id_new:
            details = str(i)

        conn = mysql.connect()  # intial connection
        cursor = conn.cursor()
        std_d = "SELECT * FROM student_reg WHERE Email_address = %s"
        sql_where = (username)

        cursor.execute(std_d,sql_where)
        assn = cursor.fetchall()

        x = cursor.rowcount

        if x > 0:
            for row in assn:
                email = str(row[6]).lower()
                Name = str(row[1]).lower()
                form = str(row[4]).lower()
        cursor.close()
        conn.close()

        conn = mysql.connect()
        cursor = conn.cursor()
        std_c_name = "SELECT * FROM books WHERE book_id = %s"
        sql_where = (details)
        cursor.execute(std_c_name, sql_where)
        assn = cursor.fetchall()

        for row in assn:
            b_name = str(row[2]).lower()
            author  = str(row[4]).lower()
            unique_id = row[0]


        cursor.close()
        conn.close()

        from datetime import datetime
        from datetime import timedelta

        more_days = (datetime.now() + timedelta(days=20)).strftime('%Y-%m-%d')
        conn = mysql.connect()  # intial connection
        cursor = conn.cursor()
        cursor.execute('INSERT INTO ' + table5 + ' (id, book_name, author, email,date) VALUES (%s, %s, %s,%s,%s)',(details, b_name, author,username,more_days))
        conn.commit()
        cursor.close()
        conn.close()

        conn = mysql.connect()  # intial connection
        cursor = conn.cursor()

        cursor.execute('UPDATE books SET Taken_by =%s,Status=%s WHERE unique_id = %s',
                       (email, "Not Available", unique_id))

        conn.commit()
        cursor.close()
        conn.close()
        return redirect('/studentbooks')
        #return "course added"

@app.route('/return_book',methods=['POST'])

def return_book():
    if request.method == 'POST':
        book_id_new = request.form.to_dict()

        for i in book_id_new:
            details = str(i)
            conn = mysql.connect()
            cursor = conn.cursor()
            std_c_name = "DELETE FROM student_books WHERE id = %s"
            sql_where = (details)
            cursor.execute(std_c_name, sql_where)
            conn.commit()

            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute('UPDATE books SET Taken_by =%s,Status=%s WHERE book_id = %s',
                           ("", "Available", details    ))
            conn.commit()
            cursor.close()
            conn.close()
        return redirect('/studentbooks')
        #return "course added"



@app.route('/logout')
def logout():
    if 'email' in session:
        session.pop('email', None)
    return redirect('/')