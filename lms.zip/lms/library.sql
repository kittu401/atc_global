-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2020 at 08:08 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_reg`
--

CREATE TABLE `admin_reg` (
  `AD_ID` int(100) NOT NULL,
  `First Name` varchar(50) NOT NULL,
  `Last Name` varchar(50) NOT NULL,
  `Email` varchar(70) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_reg`
--

INSERT INTO `admin_reg` (`AD_ID`, `First Name`, `Last Name`, `Email`, `Password`) VALUES
(2, 'nagarjuna', 'B', 'admin@admin.com', 'pbkdf2:sha256:150000$V8Tjc0y2$162bc886360967870e5721ea64ef4d4520844b0116268116922d4d84b5dfb953');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `unique_id` int(11) NOT NULL,
  `book_id` varchar(15) NOT NULL,
  `name` varchar(50) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `author` varchar(50) NOT NULL,
  `Taken_by` varchar(50) NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`unique_id`, `book_id`, `name`, `Description`, `author`, `Taken_by`, `Status`) VALUES
(5, '3', 'MEFA', 'finance analysis', 'David', 'student1@gmail.com', 'Not Available'),
(7, '234', 'mp adm mc', 'micro procesors and controllers', 'shaw', '', 'Available'),
(8, '24', 'digital image', 'image processing', 'Ryan', 'student1@gmail.com', 'Not Available'),
(10, '56', 'Finance management', 'about finance', 'Ryan', '', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `student_books`
--

CREATE TABLE `student_books` (
  `id` int(11) NOT NULL,
  `book_name` varchar(70) NOT NULL,
  `author` varchar(70) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_books`
--

INSERT INTO `student_books` (`id`, `book_name`, `author`, `email`, `date`) VALUES
(3, 'mefa', 'david', 'student1@gmail.com', '2020-01-20'),
(24, 'digital image', 'ryan', 'student1@gmail.com', '2020-01-22');

-- --------------------------------------------------------

--
-- Table structure for table `student_reg`
--

CREATE TABLE `student_reg` (
  `STD_ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Course` varchar(20) NOT NULL,
  `Semester` varchar(10) NOT NULL,
  `FormNo` varchar(100) NOT NULL,
  `Contact Number` varchar(10) NOT NULL,
  `Email_address` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Address` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_reg`
--

INSERT INTO `student_reg` (`STD_ID`, `Name`, `Course`, `Semester`, `FormNo`, `Contact Number`, `Email_address`, `Password`, `Address`) VALUES
(5, 'kishore', 'CSE', '1', '1611', '7382181611', 'student1@gmail.com', 'pbkdf2:sha256:150000$6ZoiRawe$9b7cfa15effd984070c09d07e321ae331fca5f51ec42cf2f20d393da44a94884', 'hyderabad');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_reg`
--
ALTER TABLE `admin_reg`
  ADD PRIMARY KEY (`AD_ID`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`unique_id`);

--
-- Indexes for table `student_reg`
--
ALTER TABLE `student_reg`
  ADD PRIMARY KEY (`STD_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_reg`
--
ALTER TABLE `admin_reg`
  MODIFY `AD_ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `unique_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `student_reg`
--
ALTER TABLE `student_reg`
  MODIFY `STD_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
